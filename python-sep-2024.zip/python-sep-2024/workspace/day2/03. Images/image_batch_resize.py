import os
from PIL import Image, ImageFilter, ImageOps

files = os.listdir('img')
print(files)
size = 60, 90

for file in files:
    if file.lower().endswith(".jpg"):
        im = Image.open("img/" + file)
        im.thumbnail(size)
        im.save("resized/" + file, "JPEG")

